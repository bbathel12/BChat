<nav>
  <a id="logout" href="logout.php" >Log<br> Out</a>
  <a id="profile" href="profile.php" >My<br> Profile</a>
  <a id="" href="/chat">CHAT</a>
  <a id="mute" href="#" >Mute</a>
  </nav>
