  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="/chat/scripts.js"></script>
  <link rel="stylesheet" href="/chat/chat.css">
    